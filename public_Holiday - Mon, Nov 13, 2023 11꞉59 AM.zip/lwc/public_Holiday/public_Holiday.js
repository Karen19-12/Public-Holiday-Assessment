import { LightningElement} from 'lwc';
import saveHoliday from '@salesforce/apex/PublicHoliday.saveHoliday';
import getHolidays from '@salesforce/apex/PublicHolidayCallout.getHolidays';

export default class PublicHoliday extends LightningElement {
    idNumber = '';
    disabledButton = true;
    errorMessage = '';
    dateOfBirth='';
    gender='';
    saCitizen='';
    items;

    handleIdNumberChange(event) {
        this.idNumber = event.target.value;
        this.determineValidIDNumber();
    }

//method to determine if the entered ID Number is valid & enable/disable the search button

    determineValidIDNumber() {
    
        if (this.idNumber.length === 13) {
            this.disabledButton = false;
            this.dateOfBirth=this.idNumber.slice(0,6);
            this.gender= (parseInt(this.idNumber.slice(6,10))>4999)?'Male':'Female';
            this.saCitizen=(this.idNumber.slice(10,11)=='0')?'SA Citizen':'Non SA Ctizen';
          
        } else {
            this.disabledButton = true;
            this.errorMessage = 'Enter a valid ID number.';
        }
    }
    handleSearch() {

        //submit appex to create/update record
        saveHoliday({idNumber:this.idNumber, gender:this.gender, birthdate:this.dateOfBirth,saCitizen:this.saCitizen}).then().catch(e=> console.error(e));
       
       let year;
       if(this.idNumber.slice(0)=='0') {
           year=parseInt('20'+ this.idNumber.slice(0,2));
        
       }else{
            year=parseInt('19'+ this.idNumber.slice(0,2));

       }

         // Call the function to get holidays
    getHolidays({year:year})
  .then(holidays => {
    if (holidays) {
      // Display the list of holidays to the visitor
      console.log('List of holidays:', holidays);
      this.items= holidays.response.holidays;
      
      // You can update your webpage here to display the holidays
    }  
    });}


}